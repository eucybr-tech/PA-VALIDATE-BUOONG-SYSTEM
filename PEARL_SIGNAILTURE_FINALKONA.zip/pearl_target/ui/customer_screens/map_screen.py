from urllib.parse import urlencode

from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import (
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
except ImportError:
    QWebEngineView = None

from services.schedule_manager import ScheduleManager
from services.studio_settings_manager import StudioSettingsManager
from ui.base_page import BasePage
from ui.studio_map_widget import StudioMapWidget


class StudioInfo:
    """Customer-facing studio information and booking policies."""

    _STUDIO_NAME = "Pearl's SigNAILture"
    _TECHNICIAN_NAME = "Pearl"
    _TECHNICIAN_TITLE = "Nail Technician"
    _WELCOME_TEXT = (
        "Hello, Gorgeous! Welcome to my booking page. Please take a quick peek at "
        "the policies on my highlights, then feel free to book your preferred "
        "schedule. Can't wait to see you!"
    )
    _BOOKING_POLICY = (
        "New clients pay a one-time lifetime deposit of 100 pesos. It is not "
        "deductible from the service price and is kept on file for future bookings."
    )
    _CANCELLATION_POLICY = (
        "Cancelling or rescheduling needs at least 48 hours notice, and a "
        "cancellation costs 50 pesos."
    )
    _ADDITIONAL_INFORMATION = (
        "Please arrive 5 to 10 minutes early. There is a 3-day warranty on lifting "
        "not caused by force."
    )

    def __init__(
        self, settings_manager: StudioSettingsManager | None = None
    ) -> None:
        self._settings_manager = settings_manager
        self._customer_address = ""

    @property
    def settings_manager(self) -> StudioSettingsManager | None:
        return self._settings_manager

    @property
    def studio_name(self) -> str:
        return self._STUDIO_NAME

    @property
    def technician_name(self) -> str:
        return self._TECHNICIAN_NAME

    @property
    def technician_title(self) -> str:
        return self._TECHNICIAN_TITLE

    @property
    def welcome_text(self) -> str:
        return self._WELCOME_TEXT

    @property
    def booking_policy(self) -> str:
        return self._BOOKING_POLICY

    @property
    def cancellation_policy(self) -> str:
        return self._CANCELLATION_POLICY

    @property
    def additional_information(self) -> str:
        return self._ADDITIONAL_INFORMATION

    @property
    def address(self) -> str:
        return (
            self._settings_manager.get_settings().studio_address
            if self._settings_manager is not None
            else ""
        )

    @property
    def customer_address(self) -> str:
        return self._customer_address

    def set_customer_address(self, address: str) -> None:
        if not isinstance(address, str):
            raise TypeError("address must be a string")
        self._customer_address = address.strip()


class MapScreen(BasePage):
    """Customer map and address search screen."""

    def __init__(
        self,
        studio_info: StudioInfo | None = None,
        schedule_manager: ScheduleManager | None = None,
        settings_manager: StudioSettingsManager | None = None,
        parent=None,
    ) -> None:
        self._studio_info = studio_info or StudioInfo(settings_manager)
        self._schedule_manager = schedule_manager
        self._settings_manager = settings_manager or self._studio_info.settings_manager
        super().__init__(
            {
                "studio_info": self._studio_info,
                "schedule_manager": schedule_manager,
                "studio_settings_manager": self._settings_manager,
            },
            parent,
        )
        self.refresh()

    @property
    def studio_info(self) -> StudioInfo:
        return self._studio_info

    @property
    def schedule_manager(self) -> ScheduleManager | None:
        return self._schedule_manager

    @property
    def map_widget(self) -> StudioMapWidget:
        return self._map_widget

    def build_ui(self) -> None:
        self._map_widget = StudioMapWidget(
            self._settings_manager, self._schedule_manager
        )
        self._customer_address_input = QLineEdit()
        self._customer_address_input.setPlaceholderText(
            "Enter your current address or starting location"
        )
        self._customer_address_input.setText(self._studio_info.customer_address)
        self._customer_address_input.textChanged.connect(
            self._studio_info.set_customer_address
        )
        self._customer_address_input.textChanged.connect(
            self._update_directions_controls
        )
        self._directions_status = QLabel(
            "Enter your starting location to see the route to Pearl's SigNAILture."
        )
        self._directions_status.setWordWrap(True)
        self._show_directions_button = QPushButton("Show directions in this app")
        self._show_directions_button.clicked.connect(self._show_directions)
        self._open_studio_map_button = QPushButton("Open route in Google Maps")
        self._open_studio_map_button.clicked.connect(self._open_directions_externally)
        self._open_studio_map_button.setEnabled(False)

        self._directions_view = None
        if QWebEngineView is not None:
            try:
                self._directions_view = QWebEngineView()
                self._directions_view.setMinimumHeight(360)
                self._directions_view.loadFinished.connect(
                    self._directions_load_finished
                )
                self._directions_view.hide()
            except (ImportError, RuntimeError):
                self._directions_view = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.addWidget(self._map_widget, 1)
        layout.addWidget(QLabel("Your starting location"))
        layout.addWidget(self._customer_address_input)
        layout.addWidget(self._directions_status)
        layout.addWidget(self._show_directions_button)
        if self._directions_view is not None:
            layout.addWidget(self._directions_view, 1)
        layout.addWidget(self._open_studio_map_button)

    def refresh(self) -> None:
        self._map_widget.refresh()
        if self._customer_address_input.text() != self._studio_info.customer_address:
            self._customer_address_input.setText(self._studio_info.customer_address)
        self._update_directions_controls()

    def _update_directions_controls(self, *_args) -> None:
        has_destination = bool(self._map_widget.studio_address)
        has_origin = bool(self._customer_address_input.text().strip())
        self._show_directions_button.setEnabled(has_destination and has_origin)
        self._open_studio_map_button.setEnabled(has_destination and has_origin)

    def _directions_load_finished(self, succeeded: bool) -> None:
        if succeeded:
            self._directions_status.setText(
                "Route loaded below. If directions do not appear, use the "
                "Google Maps fallback button."
            )
        else:
            self._directions_status.setText(
                "Could not load in-app directions. You can open the route in Google Maps."
            )

    @staticmethod
    def build_directions_url(origin: str, destination: str) -> str:
        """Build a Google Maps route URL from customer origin to salon destination."""
        origin = origin.strip()
        destination = destination.strip()
        if not origin or not destination:
            return ""
        return "https://www.google.com/maps/dir/?" + urlencode(
            {"api": "1", "origin": origin, "destination": destination}
        )

    def _show_directions(self) -> None:
        origin = self._customer_address_input.text().strip()
        destination = self._map_widget.studio_address.strip()
        if not origin:
            QMessageBox.information(
                self, "Starting location required", "Enter your starting location first."
            )
            return
        if not destination:
            QMessageBox.information(
                self, "Studio address unavailable", "The studio address has not been set."
            )
            return
        url = self.build_directions_url(origin, destination)
        if self._directions_view is None:
            self._directions_status.setText(
                "In-app directions are unavailable on this installation. Use the "
                "Google Maps button below instead."
            )
            self._open_directions_externally()
            return
        self._directions_status.setText(
            "Loading your route… Your starting address is sent to Google Maps to "
            "calculate directions."
        )
        self._directions_view.show()
        self._directions_view.setUrl(QUrl(url))

    def _open_directions_externally(self) -> None:
        origin = self._customer_address_input.text().strip()
        destination = self._map_widget.studio_address.strip()
        url_text = self.build_directions_url(origin, destination)
        if not url_text:
            QMessageBox.information(
                self,
                "Location details required",
                "Enter your starting location and make sure the studio address is set.",
            )
            return
        if not QDesktopServices.openUrl(QUrl(url_text)):
            QMessageBox.warning(
                self,
                "Could not open directions",
                "The route could not be opened in your browser.",
            )

