import sqlite3

from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import (
    QComboBox,
    QCompleter,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QLabel,
    QInputDialog,
    QDoubleSpinBox,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from models import Customer, QueueEntry, QueueStatus
from services.client_manager import ClientManager
from services.queue_manager import QueueManager


class QueueEmailSignals(QObject):
    completed = pyqtSignal(bool, str)


class WalkInDialog(QDialog):
    """Choose a saved client or register a new profile for a walk-in."""

    def __init__(
        self, clients: list[Customer], services: list, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Register Walk-in")
        self.setMinimumWidth(420)
        self._clients = clients
        self._services = services
        self._new_client: Customer | None = None
        self._service_combo = QComboBox()
        for service in services:
            self._service_combo.addItem(
                f"{service.name} — ₱ {service.base_price:,.2f}", service.service_id
            )
        self._service_combo.setCurrentIndex(0 if services else -1)
        self._service_price = QDoubleSpinBox()
        self._service_price.setRange(0, 1_000_000)
        self._service_price.setDecimals(2)
        self._service_price.setPrefix("₱ ")
        if services:
            self._service_price.setValue(services[0].base_price)
        self._service_combo.currentIndexChanged.connect(self._update_service_price)
        self._tabs = QTabWidget(self)

        existing_page = QWidget(self)
        existing_form = QFormLayout(existing_page)
        self._client_combo = QComboBox()
        self._client_combo.setEditable(True)
        self._client_combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self._client_combo.setPlaceholderText("Search by client name or email")
        self._client_combo.completer().setCompletionMode(
            QCompleter.CompletionMode.PopupCompletion
        )
        self._client_combo.completer().setFilterMode(Qt.MatchFlag.MatchContains)
        for client in clients:
            self._client_combo.addItem(
                f"{client.name} — {client.email}", client.email
            )
        self._client_combo.setCurrentIndex(-1)
        existing_form.addRow("Saved client", self._client_combo)

        new_page = QWidget(self)
        new_form = QFormLayout(new_page)
        self._name_edit = QLineEdit()
        self._email_edit = QLineEdit()
        self._phone_edit = QLineEdit()
        self._name_edit.setPlaceholderText("Client's full name")
        self._email_edit.setPlaceholderText("Required for the client record")
        self._phone_edit.setPlaceholderText("Optional")
        new_form.addRow("Name", self._name_edit)
        new_form.addRow("Email", self._email_edit)
        new_form.addRow("Phone", self._phone_edit)

        self._no_clients_label = QLabel(
            "No saved clients yet. Choose New Client to register this walk-in."
        )
        self._no_clients_label.setWordWrap(True)
        self._no_clients_label.setVisible(not clients)
        existing_form.addRow(self._no_clients_label)

        self._tabs.addTab(existing_page, "Existing Client")
        self._tabs.addTab(new_page, "New Client")
        # Keep both tabs clickable even when the saved-client list is empty.
        # The Existing Client tab explains why there is nothing to select.
        if not clients:
            self._tabs.setCurrentWidget(new_page)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(self._tabs)
        service_form = QFormLayout()
        service_form.addRow("Service", self._service_combo)
        service_form.addRow("Final service price", self._service_price)
        layout.addLayout(service_form)
        layout.addWidget(buttons)

    @property
    def selected_client(self) -> Customer | None:
        if self._tabs.currentIndex() == 0:
            index = self._client_combo.currentIndex()
            if index < 0:
                return None
            email = self._client_combo.itemData(index)
            return next(
                (client for client in self._clients if client.email == email), None
            )
        return self._new_client

    def _update_service_price(self, index: int) -> None:
        service_id = self._service_combo.itemData(index)
        service = next((item for item in self._services if item.service_id == service_id), None)
        if service is not None:
            self._service_price.setValue(service.base_price)

    @property
    def selected_price(self) -> float:
        return float(self._service_price.value())

    @property
    def selected_service_id(self) -> int | None:
        value = self._service_combo.currentData()
        return int(value) if value is not None else None

    @property
    def is_new_client(self) -> bool:
        return self._tabs.currentIndex() == 1

    def _validate_and_accept(self) -> None:
        if self.selected_service_id is None:
            QMessageBox.warning(
                self, "Select a service",
                "Add at least one service in Service & Pricing, then choose it for this walk-in.",
            )
            return
        if self.selected_price <= 0:
            QMessageBox.warning(
                self, "Invalid service price", "The final walk-in service price must be greater than zero."
            )
            return
        if self._tabs.currentIndex() == 0:
            index = self._client_combo.currentIndex()
            if (
                index < 0
                or self._client_combo.currentText()
                != self._client_combo.itemText(index)
                or self._client_combo.itemData(index) is None
            ):
                QMessageBox.warning(
                    self, "Select a client", "Choose a client from the saved records."
                )
                return
        else:
            try:
                self._new_client = Customer(
                    self._name_edit.text().strip(),
                    self._email_edit.text().strip(),
                    phone=self._phone_edit.text().strip() or None,
                )
            except (TypeError, ValueError) as error:
                QMessageBox.warning(self, "Invalid client details", str(error))
                return
        self.accept()


class QueuePanel(QWidget):
    """Reusable staff/admin queue controls and active-line display."""

    # Dependency injection and encapsulation: only queue services and private UI
    # state are held by this shared QWidget.
    def __init__(
        self,
        queue_manager: QueueManager,
        client_manager: ClientManager | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._queue_manager = queue_manager
        self._client_manager = client_manager
        self._entries: list[QueueEntry] = []
        self._email_signals = QueueEmailSignals(self)
        self._email_signals.completed.connect(self._show_email_result)
        self._build_ui()
        self.refresh()

        # Admin and Staff windows can be open at the same time. Poll the shared
        # queue so a walk-in added in either window appears in every queue panel
        # without requiring the user to leave and reopen the screen.
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(5_000)
        self._refresh_timer.timeout.connect(self.refresh)
        self._refresh_timer.start()

    @property
    def queue_manager(self) -> QueueManager:
        return self._queue_manager

    def _build_ui(self) -> None:
        self._now_serving = QLabel("Now serving: Nobody")
        self._now_serving.setObjectName("appTitle")

        self._queue_table = QTableWidget(0, 5)
        self._queue_table.setHorizontalHeaderLabels(
            ["Position", "Ticket", "Name", "Type", "Status"]
        )
        self._queue_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows
        )
        self._queue_table.setSelectionMode(
            QTableWidget.SelectionMode.SingleSelection)
        self._queue_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers)
        self._queue_table.horizontalHeader().setStretchLastSection(True)

        self._add_walk_in_button = QPushButton("Add Walk-in")
        self._add_walk_in_button.setProperty("variant", "primary")
        self._call_next_button = QPushButton("Call Next")
        self._call_next_button.setProperty("variant", "primary")
        self._mark_done_button = QPushButton("Mark Done")
        self._mark_done_button.setProperty("variant", "primary")
        self._cancel_button = QPushButton("Cancel Entry")
        self._skip_button = QPushButton("Skip (not here yet)")
        self._add_walk_in_button.clicked.connect(self.add_walk_in)
        self._call_next_button.clicked.connect(self.call_next)
        self._mark_done_button.clicked.connect(self.mark_done)
        self._cancel_button.clicked.connect(self.cancel_entry)
        self._skip_button.clicked.connect(self.skip_next)
        self._queue_table.itemSelectionChanged.connect(self._update_actions)

        actions = (
            self._add_walk_in_button,
            self._call_next_button,
            self._mark_done_button,
            self._cancel_button,
            self._skip_button,
        )
        layout = QVBoxLayout(self)
        layout.addWidget(self._now_serving)
        layout.addWidget(self._queue_table, 1)
        for button in actions:
            layout.addWidget(button)

    def refresh(self) -> None:
        try:
            self._entries = self._queue_manager.get_queue()
        except (sqlite3.Error, ValueError, TypeError) as error:
            self._show_error("Could not load queue", error)
            return
        now_serving = self._queue_manager.get_now_serving()
        self._now_serving.setText(
            "Now serving: Nobody"
            if now_serving is None
            else f"Now serving: {now_serving.ticket_number} — {now_serving.client_name}"
        )
        self._queue_table.setRowCount(0)
        for entry in self._entries:
            row = self._queue_table.rowCount()
            self._queue_table.insertRow(row)
            position = (
                self._queue_manager.get_position(entry.entry_id)
                if entry.entry_id is not None
                else None
            )
            values = (
                f"{position:03d}" if position is not None else "",
                entry.ticket_number or "",
                entry.client_name,
                entry.entry_type.value.replace("_", " ").title(),
                entry.status.value.title(),
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if column == 0:
                    item.setData(Qt.ItemDataRole.UserRole, entry.entry_id)
                self._queue_table.setItem(row, column, item)
        self._update_actions()

    def add_walk_in(self) -> None:
        if self._client_manager is None:
            self._show_error(
                "Walk-in registration unavailable",
                RuntimeError("Client records are not connected to the queue screen."),
            )
            return
        try:
            clients = self._client_manager.get_clients()
            services = self._queue_manager.get_services()
        except (ValueError, TypeError, sqlite3.Error) as error:
            self._show_error("Could not load client records", error)
            return

        dialog = WalkInDialog(clients, services, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        client = dialog.selected_client
        if client is None:
            self._show_error(
                "Could not add walk-in", ValueError("Select or register a client first.")
            )
            return

        try:
            if dialog.is_new_client:
                client = self._client_manager.add_client(client)
            entry = self._queue_manager.add_walk_in(client.name, client.email)
            self._queue_manager.set_walk_in_service(
                entry.entry_id, dialog.selected_service_id, dialog.selected_price
            )
        except (ValueError, TypeError, sqlite3.Error, KeyError) as error:
            self._show_error("Could not add walk-in", error)
            return
        QMessageBox.information(
            self,
            "Walk-in added",
            f"{entry.client_name} was added with ticket {entry.ticket_number}.",
        )
        self.refresh()
        self._select_entry(entry.entry_id)

    def call_next(self) -> None:
        try:
            entry = self._queue_manager.call_next(self._email_callback)
        except (ValueError, sqlite3.Error, KeyError) as error:
            self._show_error("Could not call next client", error)
            return
        self.refresh()
        self._select_entry(entry.entry_id)

    def skip_next(self) -> None:
        try:
            self._queue_manager.skip_next()
        except (ValueError, sqlite3.Error, KeyError) as error:
            self._show_error("Could not skip client", error)
            return
        self.refresh()

    def mark_done(self) -> None:
        entry = self._selected_entry()
        if entry is None:
            QMessageBox.information(
                self, "Select a queue entry", "Choose the serving entry first."
            )
            return
        if entry.entry_id is None:
            self._show_error(
                "Could not mark entry done",
                ValueError("The queue entry has not been saved"),
            )
            return
        try:
            if entry.entry_type.value == "WALK_IN":
                existing_sale = self._queue_manager.database.get_walk_in_sale(entry.entry_id)
                if existing_sale is None:
                    selected_service = self._queue_manager.get_walk_in_service(entry.entry_id)
                    if selected_service is None:
                        raise ValueError("The service for this walk-in is missing. Please cancel and add the walk-in again, selecting a service.")
                    methods = ["Cash", "GCash / QR", "Bank Transfer"]
                    amount_text = f"₱ {float(selected_service['quoted_price']):,.2f}"
                    method, accepted = QInputDialog.getItem(
                        self, "Record full payment",
                        f"Confirm receipt of the full walk-in payment ({amount_text}). Payment method:",
                        methods, 0, False,
                    )
                    if not accepted:
                        return
                    self._queue_manager.record_walk_in_payment(
                        entry.entry_id, int(selected_service["service_id"]), method,
                        float(selected_service["quoted_price"]),
                    )
            self._queue_manager.mark_done(entry.entry_id)
        except (ValueError, sqlite3.Error, KeyError, TypeError) as error:
            self._show_error("Could not complete walk-in / queue entry", error)
            return
        self.refresh()

    def cancel_entry(self) -> None:
        entry = self._selected_entry()
        if entry is None:
            QMessageBox.information(
                self, "Select a queue entry", "Choose an active entry to cancel."
            )
            return
        if entry.entry_id is None:
            self._show_error(
                "Could not cancel queue entry",
                ValueError("The queue entry has not been saved"),
            )
            return
        if entry.entry_type.value == "BOOKED":
            confirmation = (
                "This queue entry is linked to a booked appointment. "
                "Continuing will also cancel the appointment and apply the "
                "studio's cancellation policy, including any applicable late fee. "
                "Do you want to continue?"
            )
        else:
            confirmation = "Remove this walk-in from today's queue?"
        answer = QMessageBox.question(
            self,
            "Confirm cancellation",
            confirmation,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self._queue_manager.cancel_entry(entry.entry_id)
        except (ValueError, sqlite3.Error, KeyError, TypeError) as error:
            self._show_error("Could not cancel queue entry", error)
            return
        self.refresh()

    def _selected_entry(self) -> QueueEntry | None:
        row = self._queue_table.currentRow()
        if row < 0:
            return None
        item = self._queue_table.item(row, 0)
        entry_id = item.data(Qt.ItemDataRole.UserRole) if item else None
        return next((entry for entry in self._entries if entry.entry_id == entry_id), None)

    def _select_entry(self, entry_id: int | None) -> None:
        if entry_id is None:
            return
        for row in range(self._queue_table.rowCount()):
            item = self._queue_table.item(row, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == entry_id:
                self._queue_table.selectRow(row)
                return

    def _update_actions(self) -> None:
        selected = self._selected_entry()
        serving = self._queue_manager.get_now_serving()
        self._call_next_button.setEnabled(
            serving is None
            and any(entry.status is QueueStatus.WAITING for entry in self._entries)
        )
        self._mark_done_button.setEnabled(
            selected is not None and selected.status is QueueStatus.SERVING
        )
        self._cancel_button.setEnabled(
            selected is not None
            and selected.status in (QueueStatus.WAITING, QueueStatus.SERVING)
        )
        self._skip_button.setEnabled(
            sum(entry.status is QueueStatus.WAITING for entry in self._entries) > 1
        )

    def _email_callback(self, success: bool, error: str | None) -> None:
        self._email_signals.completed.emit(success, error or "")

    def _show_email_result(self, success: bool, error: str) -> None:
        if not success:
            QMessageBox.warning(
                self,
                "Email notification",
                "Saved, but the email could not be sent"
                + (f": {error}" if error else ""),
            )

    def _show_error(self, title: str, error: Exception) -> None:
        QMessageBox.critical(self, title, str(error))
