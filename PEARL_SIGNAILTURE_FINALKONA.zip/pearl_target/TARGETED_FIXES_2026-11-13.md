# Targeted fixes (2026-11-13)

Only the requested areas were changed:
- Client form validation continues to validate before closing, preserving entered values on errors.
- Walk-in Existing Client and New Client tabs remain clickable even when there are no saved clients; the existing-client tab explains the empty state.
- Customer appointment calendar is compacted to keep all week rows visible above the fixed payment summary on typical laptop-sized windows.
- Loyalty instructions and Terms & Conditions are combined into one card.

No stylesheet/color theme changes were made.
