from datetime import date, datetime
from pathlib import Path

import pytest

from database import Database
from models import Customer, Service
from services.appointment_manager import AppointmentManager
from services.loyalty_manager import LoyaltyManager
from services.pricing_calculator import PricingCalculator
from services.queue_manager import QueueManager


class _NoopNotifications:
    def send_queue_called_async(self, _email, callback):
        callback(True, None)

    def send_appointment_status_async(self, *_args, **_kwargs):
        callback = _args[8] if len(_args) > 8 else _kwargs.get("callback")
        if callback:
            callback(True, None)


@pytest.fixture
def queue_env(tmp_path: Path):
    database = Database(tmp_path / "queue-validation.sqlite")
    database.initialize_schema()
    client = database.add_client(
        Customer("Queue Test Client", "queue-test@example.test", deposit_paid=True)
    )
    service = database.add_service(Service("Queue Test Service", 650, duration_minutes=60))
    appointments = AppointmentManager(
        database, PricingCalculator(), _NoopNotifications(), LoyaltyManager(database)
    )
    queue = QueueManager(database, appointments)
    yield database, queue, client, service
    database.close()


@pytest.mark.parametrize("bad_name", ["akshdud", "1k2g33y2t13", "213123", "!!!"])
def test_walk_in_rejects_gibberish_names_before_saving(queue_env, bad_name):
    _database, queue, _client, _service = queue_env
    with pytest.raises((ValueError, TypeError)):
        queue.add_walk_in(bad_name)
    assert queue.get_queue(date.today()) == []


def test_cancelled_walk_in_cannot_erase_a_recorded_payment(queue_env):
    database, queue, client, service = queue_env
    entry = queue.add_walk_in(client.name, client.email)
    queue.set_walk_in_service(entry.entry_id, service.service_id, 650)
    queue.call_next()
    sale = queue.record_walk_in_payment(
        entry.entry_id, service.service_id, "Cash", 650
    )

    with pytest.raises(ValueError, match="already has a recorded payment"):
        queue.cancel_entry(entry.entry_id)

    assert database.get_walk_in_sale(entry.entry_id) is not None
    saved_entry = database.get_queue_entry(entry.entry_id)
    assert saved_entry.status.value == "SERVING"


def test_cancelled_booked_entry_is_not_recreated_by_queue_refresh(queue_env):
    database, queue, client, service = queue_env
    from datetime import time
    from models import Appointment, AppointmentStatus

    appointment_time = datetime.combine(date.today(), time(14, 0))
    appointment = database.add_appointment(
        Appointment(
            client_email=client.email,
            service_id=service.service_id,
            appointment_time=appointment_time,
            status=AppointmentStatus.CONFIRMED,
            total_price=650,
            duration_minutes=60,
        )
    )
    appointment_id = appointment.appointment_id
    entry = queue.enroll_booked(appointment_id)
    assert entry is not None

    queue.cancel_entry(entry.entry_id)
    refreshed = queue.get_queue(date.today())

    assert all(item.entry_id != entry.entry_id for item in refreshed)
    saved = database.get_queue_entry(entry.entry_id)
    assert saved.status.value == "CANCELLED"
    assert database.get_appointment(appointment_id).status.value == "CANCELLED"
