from datetime import date, datetime

import pytest

from database import Database
from models import Customer, QueueEntry, QueueEntryType, QueueStatus, Service


def _prepared_database(tmp_path):
    database = Database(tmp_path / "walkin.sqlite")
    database.initialize_schema()
    database.add_client(Customer("Walk-in Client", "walkin@example.com"))
    service = database.add_service(Service("Basic Gel", 500))
    entry = QueueEntry(
        "Walk-in Client",
        QueueEntryType.WALK_IN,
        status=QueueStatus.SERVING,
        client_email="walkin@example.com",
        created_at=datetime.now(),
        queue_date=date.today(),
        sort_time=datetime.now(),
    )
    entry = database.add_queue_entry(entry)
    database.set_walk_in_service(entry.entry_id, service.service_id, 650)
    return database, service, entry


def test_walk_in_full_payment_is_in_payments_and_revenue_reports(tmp_path):
    database, service, entry = _prepared_database(tmp_path)
    try:
        pending = database.get_walk_in_service(entry.entry_id)
        assert pending["quoted_price"] == 650
        sale = database.record_walk_in_sale(
            entry.entry_id, service.service_id, "GCash / QR", pending["quoted_price"]
        )
        assert sale["final_price"] == 650
        assert sale["amount_paid"] == 650
        assert sale["payment_method"] == "GCash / QR"
        assert database.get_all_payment_rows()[0]["payment_type"] == "walk_in"
        assert database.get_report_revenue(date.today(), date.today()) == 650
        report = database.get_report_by_service(date.today(), date.today())
        basic_gel = next(row for row in report if row["service_name"] == "Basic Gel")
        assert basic_gel["appointment_count"] == 1
        assert basic_gel["revenue"] == 650
        visit_types = database.get_report_by_visit_type(date.today(), date.today())
        walk_in = next(row for row in visit_types if row["visit_type"] == "WALK_IN")
        assert walk_in["revenue"] == 650
    finally:
        database.close()


def test_walk_in_payment_rejects_invalid_method_and_duplicate(tmp_path):
    database, service, entry = _prepared_database(tmp_path)
    try:
        with pytest.raises(ValueError):
            database.record_walk_in_sale(entry.entry_id, service.service_id, "QR")
        pending = database.get_walk_in_service(entry.entry_id)
        database.record_walk_in_sale(entry.entry_id, service.service_id, "Cash", pending["quoted_price"])
        with pytest.raises(ValueError, match="already been recorded"):
            database.record_walk_in_sale(entry.entry_id, service.service_id, "Cash", pending["quoted_price"])
    finally:
        database.close()


def test_walk_in_service_and_quoted_price_survive_database_reopen(tmp_path):
    path = tmp_path / "persistent-walkin.sqlite"
    database = Database(path)
    database.initialize_schema()
    database.add_client(Customer("Persistent Walk-in", "persist@example.com"))
    service = database.add_service(Service("Premium Gel", 700))
    entry = database.add_queue_entry(
        QueueEntry(
            "Persistent Walk-in", QueueEntryType.WALK_IN,
            status=QueueStatus.SERVING,
            client_email="persist@example.com",
            created_at=datetime.now(), queue_date=date.today(), sort_time=datetime.now(),
        )
    )
    database.set_walk_in_service(entry.entry_id, service.service_id, 950)
    database.close()

    reopened = Database(path)
    try:
        reopened.initialize_schema()
        pending = reopened.get_walk_in_service(entry.entry_id)
        assert pending == {"service_id": service.service_id, "quoted_price": 950.0}
        sale = reopened.record_walk_in_sale(
            entry.entry_id, service.service_id, "Bank Transfer", 950
        )
        assert sale["amount_paid"] == 950
    finally:
        reopened.close()


def test_map_settings_are_persisted_across_database_reopen(tmp_path):
    from models import StudioSettings

    path = tmp_path / "map-settings.sqlite"
    database = Database(path)
    database.initialize_schema()
    settings = StudioSettings(
        maps_embed_url="https://www.google.com/maps/embed?pb=test",
        map_latitude="14.2568824",
        map_longitude="121.3663611",
        map_image_path="assets/map/laguna-map.png",
        map_link_url="https://www.google.com/maps?q=14.2568824,121.3663611",
    )
    database.update_studio_settings(settings)
    database.close()

    reopened = Database(path)
    try:
        reopened.initialize_schema()
        saved = reopened.get_studio_settings()
        assert saved.maps_embed_url == settings.maps_embed_url
        assert saved.map_latitude == "14.2568824"
        assert saved.map_longitude == "121.3663611"
        assert saved.map_image_path == "assets/map/laguna-map.png"
        assert saved.map_link_url == settings.map_link_url
    finally:
        reopened.close()
