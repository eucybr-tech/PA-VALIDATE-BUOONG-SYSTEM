from datetime import date, datetime

from database import Database
from models import (
    AppointmentStatus,
    QueueEntry,
    QueueEntryType,
    QueueStatus,
)
from services.appointment_manager import AppointmentManager
from services.notification_service import EmailCallback
from models._validation import validate_person_name


class QueueManager:
    """Manages daily lines and computes live positions from active entries."""

    def __init__(
        self,
        database: Database,
        appointment_manager: AppointmentManager,
    ) -> None:
        self._database = database
        self._appointment_manager = appointment_manager
        appointment_manager.set_queue_manager(self)

    @property
    def appointment_manager(self) -> AppointmentManager:
        return self._appointment_manager

    @property
    def database(self) -> Database:
        return self._database

    def add_walk_in(
        self, name: str, client_email: str | None = None
    ) -> QueueEntry:
        """Add a walk-in, optionally linked to an existing saved client profile."""
        name = validate_person_name(name, "Client name")

        normalized_email = None
        if client_email is not None:
            if not isinstance(client_email, str) or not client_email.strip():
                raise ValueError("A valid client email is required")
            normalized_email = client_email.strip().lower()
            client = self._database.get_client(normalized_email)
            if client is None:
                raise ValueError("The selected client profile could not be found")
            # Always use the saved profile as the source of truth, and
            # validate it at this service boundary as well.
            name = validate_person_name(client.name, "Client name")
            normalized_email = client.email

        now = datetime.now()
        entry = QueueEntry(
            client_name=name.strip(),
            client_email=normalized_email,
            entry_type=QueueEntryType.WALK_IN,
            created_at=now,
            queue_date=now.date(),
            sort_time=now,
        )
        return self._database.add_queue_entry(entry)

    def get_services(self):
        """Return configured salon services for walk-in checkout."""
        return self._database.get_services()

    def set_walk_in_service(
        self, entry_id: int, service_id: int, quoted_price: float | None = None
    ) -> None:
        self._database.set_walk_in_service(entry_id, service_id, quoted_price)

    def get_walk_in_service(self, entry_id: int) -> dict[str, object] | None:
        return self._database.get_walk_in_service(entry_id)

    def record_walk_in_payment(
        self, entry_id: int, service_id: int, payment_method: str,
        quoted_price: float | None = None,
    ) -> dict[str, object]:
        return self._database.record_walk_in_sale(
            entry_id, service_id, payment_method, quoted_price
        )

    def enroll_booked(self, appointment_id: int) -> QueueEntry:
        appointment = self._appointment_manager.get_appointment(appointment_id)
        if appointment.status is not AppointmentStatus.CONFIRMED:
            raise ValueError("Only confirmed appointments can join the queue")
        appointment_time = self._as_datetime(appointment.appointment_time)
        if appointment_time.date() != date.today():
            raise ValueError("Appointments can only join the queue on their appointment day")
        entry = self._database.get_queue_entry_by_appointment(appointment_id)
        if entry is None:
            entry = QueueEntry(
                client_name=self._appointment_manager.get_client_name(
                    appointment.client_email
                ),
                client_email=appointment.client_email,
                entry_type=QueueEntryType.BOOKED,
                created_at=datetime.now(),
                queue_date=appointment_time.date(),
                sort_time=appointment_time,
                appointment_id=appointment_id,
            )
            return self._database.add_queue_entry(entry, appointment_id)

        changed = (
            entry.queue_date != appointment_time.date()
            or entry.sort_time != appointment_time
        )
        if changed:
            self._clear_skips_after(entry)
            entry.update_schedule(appointment_time.date(), appointment_time)
            entry.update_skip(0, None)
            if entry.status in (QueueStatus.DONE, QueueStatus.CANCELLED):
                entry.update_status(QueueStatus.WAITING)
                entry.update_skip(0, None)
            self._database.update_queue_entry(entry)
        # A cancelled queue entry stays cancelled until its appointment is
        # rescheduled. Refreshing the queue must not silently revive it.
        return entry

    def sync_appointment(self, appointment_id: int) -> None:
        appointment = self._appointment_manager.get_appointment(appointment_id)
        entry = self._database.get_queue_entry_by_appointment(appointment_id)
        if entry is None:
            if (
                appointment.status is AppointmentStatus.CONFIRMED
                and self._as_datetime(appointment.appointment_time).date()
                == date.today()
            ):
                self.enroll_booked(appointment_id)
            return

        if appointment.status is AppointmentStatus.CONFIRMED:
            appointment_time = self._as_datetime(appointment.appointment_time)
            if appointment_time.date() != date.today():
                changed = entry.status is not QueueStatus.CANCELLED
                entry.update_status(QueueStatus.CANCELLED)
                self._clear_skips_after(entry)
                if changed:
                    self._database.update_queue_entry(entry)
                return
            changed = (
                entry.queue_date != appointment_time.date()
                or entry.sort_time != appointment_time
            )
            if changed:
                self._clear_skips_after(entry)
                entry.update_schedule(appointment_time.date(), appointment_time)
                entry.update_skip(0, None)
            if entry.status in (QueueStatus.DONE, QueueStatus.CANCELLED):
                entry.update_status(QueueStatus.WAITING)
                entry.update_skip(0, None)
                changed = True
        else:
            desired_status = (
                QueueStatus.DONE
                if appointment.status is AppointmentStatus.COMPLETED
                else QueueStatus.CANCELLED
            )
            changed = entry.status is not desired_status
            entry.update_status(desired_status)
            self._clear_skips_after(entry)
        if changed:
            self._database.update_queue_entry(entry)

    def get_queue(self, queue_date: date | None = None) -> list[QueueEntry]:
        requested_date = queue_date or date.today()
        if requested_date != date.today():
            return []
        return self._get_active_entries(requested_date)

    def get_position(self, entry_id: int) -> int | None:
        entry = self._database.get_queue_entry(entry_id)
        if entry is None or entry.queue_date != date.today():
            return None
        active = self._get_active_entries(entry.queue_date)
        return next(
            (
                position
                for position, candidate in enumerate(active, start=1)
                if candidate.entry_id == entry_id
            ),
            None,
        )

    def call_next(self, email_callback: EmailCallback | None = None) -> QueueEntry:
        active = self._get_active_entries(date.today())
        if any(entry.status is QueueStatus.SERVING for entry in active):
            raise ValueError("A client is already being served")
        next_entry = next(
            (entry for entry in active if entry.status is QueueStatus.WAITING),
            None,
        )
        if next_entry is None:
            raise ValueError("There are no waiting clients in today's queue")
        self._clear_skips_after(next_entry)
        next_entry.update_skip(0, None)
        next_entry.update_status(QueueStatus.SERVING)
        self._database.update_queue_entry(next_entry)
        if (
            next_entry.entry_type is QueueEntryType.BOOKED
            and next_entry.client_email is not None
        ):
            self._appointment_manager.notify_queue_called(
                next_entry.client_email,
                email_callback or (lambda _success, _error: None),
            )
        return next_entry

    def mark_done(self, entry_id: int) -> QueueEntry:
        entry = self._get_today_entry(entry_id)
        if entry.status is not QueueStatus.SERVING:
            raise ValueError("Only the serving queue entry can be marked done")
        self._clear_skips_after(entry)
        entry.update_status(QueueStatus.DONE)
        self._database.update_queue_entry(entry)
        appointment_id = entry.appointment_id
        if entry.entry_type is QueueEntryType.BOOKED and appointment_id is not None:
            appointment = self._appointment_manager.get_appointment(appointment_id)
            if appointment.status is AppointmentStatus.CONFIRMED:
                self._appointment_manager.update_status(
                    appointment_id,
                    AppointmentStatus.COMPLETED,
                    lambda _success, _error: None,
                )
        return entry

    def cancel_entry(self, entry_id: int) -> QueueEntry:
        entry = self._get_today_entry(entry_id)
        if entry.status not in (QueueStatus.WAITING, QueueStatus.SERVING):
            raise ValueError("Only active queue entries can be cancelled")
        if (
            entry.entry_type is QueueEntryType.WALK_IN
            and entry.entry_id is not None
            and self._database.get_walk_in_sale(entry.entry_id) is not None
        ):
            raise ValueError(
                "This walk-in already has a recorded payment. Mark it done instead; "
                "the payment record must not be removed by cancelling the queue entry."
            )
        if (
            entry.entry_type is QueueEntryType.BOOKED
            and entry.appointment_id is not None
        ):
            appointment = self._appointment_manager.get_appointment(
                entry.appointment_id
            )
            if appointment is not None and appointment.status is AppointmentStatus.COMPLETED:
                raise ValueError(
                    "This appointment is already completed. Its payment and loyalty "
                    "history must be preserved; it cannot be cancelled from the queue."
                )
            if appointment is not None and appointment.status is AppointmentStatus.CONFIRMED:
                # Cancelling a booked client's queue slot also cancels the
                # underlying appointment, so it cannot later be completed
                # and incorrectly earn a loyalty stamp.
                self._appointment_manager.update_status(
                    entry.appointment_id,
                    AppointmentStatus.CANCELLED,
                    lambda _success, _error: None,
                    late_confirmation=True,
                )
                refreshed = self._database.get_queue_entry(entry_id)
                if refreshed is None:
                    raise RuntimeError("Cancelled queue entry could not be reloaded")
                return refreshed

        self._clear_skips_after(entry)
        entry.update_status(QueueStatus.CANCELLED)
        self._database.update_queue_entry(entry)
        return entry

    def skip_next(self) -> QueueEntry:
        waiting = [
            entry
            for entry in self._get_active_entries(date.today())
            if entry.status is QueueStatus.WAITING
        ]
        if len(waiting) < 2:
            raise ValueError("There must be another waiting client to skip behind")
        entry, following = waiting[:2]
        self._clear_skips_after(entry)
        entry.update_skip(entry.skip_count + 1, following.entry_id)
        self._database.update_queue_entry(entry)
        return entry

    def get_now_serving(self, queue_date: date | None = None) -> QueueEntry | None:
        return next(
            (
                entry
                for entry in self._get_active_entries(queue_date or date.today())
                if entry.status is QueueStatus.SERVING
            ),
            None,
        )

    def find_entry(self, ticket_or_email: str) -> QueueEntry | None:
        query = ticket_or_email.strip().casefold()
        if not query:
            return None
        matches = [
            entry for entry in self._get_active_entries(date.today())
            if entry.status in (QueueStatus.WAITING, QueueStatus.SERVING)
            and (
                (entry.ticket_number or "").casefold() == query
                or (entry.client_email or "").casefold() == query
            )
        ]
        return matches[0] if matches else None

    def _get_active_entries(self, queue_date: date) -> list[QueueEntry]:
        if queue_date != date.today():
            return []
        for appointment in self._appointment_manager.get_appointments_for_date(
            queue_date
        ):
            if appointment.status is AppointmentStatus.CONFIRMED:
                appointment_id = appointment.appointment_id
                if appointment_id is not None:
                    self.enroll_booked(appointment_id)
        active = [
            entry
            for entry in self._database.get_queue_entries(queue_date)
            if entry.status in (QueueStatus.WAITING, QueueStatus.SERVING)
        ]
        serving = sorted(
            (entry for entry in active if entry.status is QueueStatus.SERVING),
            key=lambda entry: (entry.sort_time, entry.entry_id or 0),
        )
        waiting = sorted(
            (entry for entry in active if entry.status is QueueStatus.WAITING),
            key=lambda entry: (entry.sort_time, entry.entry_id or 0),
        )
        return serving + self._apply_skip_order(waiting)

    @staticmethod
    def _apply_skip_order(entries: list[QueueEntry]) -> list[QueueEntry]:
        persisted_entries = [entry for entry in entries if entry.entry_id is not None]
        if len(persisted_entries) != len(entries):
            return entries
        by_id = {
            entry.entry_id: entry
            for entry in persisted_entries
            if entry.entry_id is not None
        }
        rank = {
            entry.entry_id: index
            for index, entry in enumerate(persisted_entries)
            if entry.entry_id is not None
        }
        successors: dict[int, list[int]] = {entry_id: [] for entry_id in by_id}
        indegree = {entry_id: 0 for entry_id in by_id}
        for entry in persisted_entries:
            target_id = entry.skip_after_entry_id
            if (
                entry.entry_id is not None
                and entry.skip_count > 0
                and target_id in by_id
                and target_id != entry.entry_id
            ):
                successors[target_id].append(entry.entry_id)
                indegree[entry.entry_id] += 1
        ready = sorted(
            (entry_id for entry_id, count in indegree.items() if count == 0),
            key=rank.__getitem__,
        )
        ordered: list[QueueEntry] = []
        while ready:
            entry_id = ready.pop(0)
            ordered.append(by_id[entry_id])
            for successor_id in successors[entry_id]:
                indegree[successor_id] -= 1
                if indegree[successor_id] == 0:
                    ready.append(successor_id)
                    ready.sort(key=rank.__getitem__)
        if len(ordered) != len(entries):
            ordered.extend(
                by_id[entry_id]
                for entry_id in sorted(
                    (key for key, count in indegree.items() if count),
                    key=rank.__getitem__,
                )
            )
        return ordered

    def _clear_skips_after(self, target: QueueEntry) -> None:
        if target.entry_id is None:
            return
        for entry in self._database.get_queue_entries(target.queue_date):
            if entry.skip_after_entry_id == target.entry_id:
                entry.update_skip(0, None)
                self._database.update_queue_entry(entry)

    def _get_today_entry(self, entry_id: int) -> QueueEntry:
        entry = self._database.get_queue_entry(entry_id)
        if entry is None or entry.queue_date != date.today():
            raise KeyError(f"No queue entry found with ID {entry_id} for today's queue")
        return entry

    @staticmethod
    def _as_datetime(value: datetime | str) -> datetime:
        return value if isinstance(value, datetime) else datetime.fromisoformat(value)
