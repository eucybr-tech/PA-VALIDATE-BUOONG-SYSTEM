import math
import re


def validate_nonempty_text(value: str, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    return value.strip()


def validate_optional_text(value: str | None, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string or None")
    return value.strip()


def validate_nonnegative_number(value: int | float, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be a number")
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise ValueError(f"{field_name} must be a finite, non-negative number")
    return number


def validate_positive_integer(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{field_name} must be an integer")
    if value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def validate_email(value: str) -> str:
    """Return a normalized email or reject malformed input."""
    if not isinstance(value, str):
        raise TypeError("email must be text")
    email = value.strip().lower()
    if len(email) > 254 or not re.fullmatch(
        r"[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?)+",
        email, re.IGNORECASE
    ):
        raise ValueError("Enter a valid email address")
    local_part, domain = email.rsplit("@", 1)
    if (
        ".." in local_part
        or local_part.startswith(".")
        or local_part.endswith(".")
        or ".." in domain
    ):
        raise ValueError("Enter a valid email address")
    return email


def validate_person_name(value: str, field_name: str = "name") -> str:
    """Validate a person's name and reject obvious random keyboard input.

    This intentionally checks structure rather than maintaining a dictionary of
    accepted names, so unfamiliar, regional, and culturally diverse names remain
    valid. Digits/symbols are rejected; common punctuation and accented letters
    are allowed. The letter y is treated as a vowel for names such as Lyn.
    """
    name = validate_nonempty_text(value, field_name)
    if len(name) > 100 or not all(
        char.isalpha() or char in " .-'’" for char in name
    ) or not any(char.isalpha() for char in name):
        raise ValueError(f"{field_name} contains invalid characters or is too long")

    vowel_chars = set(
        "aeiouyáàâäãåæéèêëíìîïóòôöõøúùûüýÿ"
    )
    common_initial_clusters = (
        "sch", "scr", "shr", "sph", "spl", "spr", "squ", "str", "thr"
    )
    words = [part for part in re.split(r"[\s.'’\-]+", name) if part]
    for word in words:
        letters = [char.casefold() for char in word if char.isalpha()]
        if not letters:
            continue
        if len(letters) >= 3:
            vowel_count = sum(char in vowel_chars for char in letters)
            allowed_initial_cluster = any(
                word.casefold().startswith(cluster)
                for cluster in common_initial_clusters
            )
            if vowel_count == 0 or (
                vowel_count / len(letters) < 0.20 and not allowed_initial_cluster
            ):
                raise ValueError(f"{field_name} does not look like a valid name")

            # Catch obvious consonant-keysmashes such as "akshdud" while
            # preserving recognized surname clusters such as "Schmidt".
            run = 0
            longest_run = 0
            for char in letters:
                if char not in vowel_chars:
                    run += 1
                    longest_run = max(longest_run, run)
                else:
                    run = 0
            if longest_run >= 4 and not allowed_initial_cluster:
                raise ValueError(f"{field_name} does not look like a valid name")
    return name
