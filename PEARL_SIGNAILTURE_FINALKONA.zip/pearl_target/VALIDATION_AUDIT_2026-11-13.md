# Validation Audit — 2026-11-13

## Fixes in this update
- Strengthened `validate_person_name` to reject obvious random letter strings (including `akshdud`) as well as numeric/alphanumeric names.
- Kept common real-name forms valid, including spaces, initials, hyphens, apostrophes, accents, short surnames such as `Ng`, and recognized surname clusters such as `Schmidt`.
- Applied the same person-name rule to the saved studio owner/provider display name when it is non-empty.
- Added regression tests for the supplied invalid examples and legitimate names.

## Person-name entry points covered by model/service validation
- Customer/client records (admin Client Management)
- Walk-in registration (creates a `Customer`)
- Public/customer appointment booking (validates name and creates a `Customer`)
- Admin/staff account display names (`AccountUser` / `User` model)
- Studio owner/provider name in Studio Settings

## Validation boundaries
- Usernames, passwords, email addresses, phone numbers, prices, durations, URLs, addresses, service descriptions, gallery descriptions, and notes require their own field-specific rules; they must not be run through person-name validation.
- Search boxes and comments/notes are not identity fields and should accept normal free text.
- No heuristic can prove that a name belongs to a real person. This rule rejects clear keyboard-mash patterns, not every unfamiliar name.

## Test results
- `python -m pytest -q tests/test_validation_rules.py`: 5 passed.
- `python -m compileall -q .`: passed.
- Full pytest collection could not run in this environment because PyQt6 is not installed; GUI-dependent tests fail during import, not due to assertion failures.
